Изучение емкости
----------------

Цель
----

Экспериментальное подтверждение расчетов времени насыщения конденсатора.

Описание опыта
--------------

Дана RC цепь с генератором прямоугольных импульсов.
                              
            │ │ C1   ┌────┐ R1  
       ┌────┤ ├──────┤    ├────┐
       │    │ │      └────┘    │
       │                       │
       │                       │
       │       ┌────────┐      │
       └───────┤  Gen   ├──────┘
               └────────┘

Нужно проверить правильность расчетов времени заряда конденсатора на полностью разряженном конденсаторе.
Интересовать будет перый импульс при включении конденсатора.
Задаем частоту с таким расчетом, чтобы за время первого импульса полностью разряженный конденсатор зарядился в течении времени:
- 1 Тау
- 3 Тау
- 5 Тау

Дополнительно понаблюдать за зарядом и разрядом конденсатора на последующих полупериодах.
Теоретически, первый заряд конденсатора, когда он был полностью разряжен, будет максимальным.
Второй заряд на втором полупериоде будет минимальным, поскольку конденсатор будет разряжаться максимальное время и на заряд останется меньше всего времени.
Последующие заряды будут варьировать в пределах от первого максимального заряда, до второго минимального заряда.

Ожидаемый результат
-------------------

Теоретические расчеты:

#. t = 0.001 sec. (1 Тау); F = 500.0 Hz.; 1.264 V.
#. t = 0.003 sec. (3 Тау); F = 166.7 Hz.; 1.9 V.
#. t = 0.005 sec. (5 Тау); F = 100.0 Hz.; 1.987 V.

.. code-block::

	import math

	# u(t) = U * (1 - math.e**(-t/RC))  # charge
	# https://calcland.ru/calculator/vremya-zaryada-kondensatora-napryazhenie-pri-zaryade
	# u(t) = U * math.e^(-t/RC)  # discharge
	# https://calcland.ru/calculator/vremya-razryada-kondensatora-napryazhenie-pri-razryade

	r1 = 1000  # Om
	c1 = 0.000001  # 1 uF
	u = 2  # V

	num_tau = 1
	tau = r1 * c1 * num_tau
	print(f't = {tau} sec. ({num_tau} Тау); F = {round(1/(2*tau), 1)} Hz.; {round(u * (1 - math.e**(-tau/(r1 * c1))), 3)} V.')
	num_tau = 3
	tau = r1 * c1 * num_tau
	print(f't = {tau} sec. ({num_tau} Тау); F = {round(1/(2*tau), 1)} Hz.; {round(u * (1 - math.e**(-tau/(r1 * c1))), 3)} V.')
	num_tau = 5
	tau = r1 * c1 * num_tau
	print(f't = {tau} sec. ({num_tau} Тау); F = {round(1/(2*tau), 1)} Hz.; {round(u * (1 - math.e**(-tau/(r1 * c1))), 3)} V.')

Лабораторна работа
------------------

Параметры цепи:

Сигнал: прямоугольные импульсы.

R1 = 1 kOm
C1 = 1 mkF
U = 4 V (-2; +2)

Изменение падения напряжения на сопротивлении
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

           ┌────┐
       ┌───┤Ch1 ├──────────────┐
       │   └────┘    ┌────┐    │
       │           ┌─┤ Ch2├────┤
       │           │ └────┘    │
       │      C1   │       R1  │
       │  │ │      │ ┌────┐    │
       ├──┤ ├──────┴─┤    ├────┤
       │  │ │        └────┘    │
       │                       │
       │                       │
       │       ┌────────┐      │
       └───────┤  Gen   ├──────┘
               └────────┘

Схема 1. Измерение на сопротивлении.

Результаты измерений:

1. F=500 Hz. В момент запуска генератора.

2. F=167 Hz. В момент запуска генератора.

3. F=100 Hz. В момент запуска генератора.

Изменение падения напряжения на конденсаторе
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

           ┌────┐
       ┌───┤Ch1 ├──────────────┐
       │   └────┘    ┌────┐    │
       │           ┌─┤ Ch2├────┤
       │           │ └────┘    │
       │      R1   │       C1  │
       │ ┌────┐    │    │ │    │
       ├─┤    ├────┴────┤ ├────┤
       │ └────┘         │ │    │
       │                       │
       │                       │
       │       ┌────────┐      │
       └───────┤  Gen   ├──────┘
               └────────┘

Схема 2. Измерение на емкости.

Результаты измерений:

1. F=500 Hz. В момент запуска генератора.

2. F=167 Hz. В момент запуска генератора.

3. F=100 Hz. В момент запуска генератора.

Ошибки ожидания
---------------

1. 

Выводы
------

1. Напряжение на резисторе в момент переключения полярности импульса генератора доходит до 3.8В. (при напряжении генератора 2В.).
Т.е. напряжение, накопленное на обкладках конденсатора складывается с подаваемым напряжением.

2. Расчетное напряжение на обкладках конденсатора примерно совпадает с полученным в результате измерений.
Ресчетное напряжение на обкдадках конденсатора для частоты 167 Гц (3 Тау) равно 1.899 В.
Полученное в результате измерений на первом импульсе 1.920 В.
Ресчетное напряжение на обкдадках конденсатора для частоты 500 Гц (1 Тау) равно 1.257 В.
Полученное в результате измерений на первом импульсе 1.260 В.

3. Как и предполагалось, первый заряд конденсатора (когда он полностью разряжен) максимальный, второй минимальный.
(Теоретическое предположение: Теоретически, первый заряд конденсатора, когда он был полностью разряжен, будет максимальным.
Второй заряд на втором полупериоде будет минимальным, поскольку конденсатор будет разряжаться максимальное время и на заряд останется меньше всего времени.)
Однако, сдедующее предположение не подтвердилось. Все последующие заряды, приметно, одинаковые, между максимальным и минимальным.
(Теоретическое предположение: Последующие заряды будут варьировать в пределах от первого максимального заряда, до второго минимального заряда.)

Вопросы
-------

1. Что будет, если на заряженный конденсатор подать более высокое напряжение? Будет ли он заряжаться по экспоненте?
Поставить эксперимент. Сделать суммированную кривую из импульсов двух уровней.
На первом уровне конденсатор нужно зарядить до 5 тау. Потом должен поступить воторой импуль в два раза больше по напряжению чем первый.

2. Как разяжается не полностью заряженный конденсатор?
Основное предположение, что по формуле разряда конденсатора, но начиная с точки, до которой конденсатор был заряжен.
# u(t) = U * math.e^(-t/RC)  # discharge
# https://calcland.ru/calculator/vremya-razryada-kondensatora-napryazhenie-pri-razryade
Например, если конденсатора заряжали в течении времени Тау на напряжении 1В (т.е. конденсатор заряжен до 0.632В), то разряд будет происходить по кривой разряда, но с момента 0.632В.
Проверить экспериментально.

# Discharge

import polars as pl
import math
import hvplot.polars  # pip install hvplot

t_range = np.arange(0, 0.001 * 5, 0.00001)

r1 = 1000  # Om
c1 = 0.000001  # 1 uF
u = 1  # V

ldf = pl.LazyFrame(
    {
        't': t_range,
        'u': [u * math.e**(-t/(r1 * c1)) for t in t_range]
    }
).filter(pl.col('u')<0.632)

ldf.collect().hvplot.line(
    x='t', y='u',
    ylim=(0, u),
    # width=300,  # width (default=700)/height (default=300): int
)

3. Как (по какой формуле) будет происходить разряд полностью или частично заряженного конденсатора, если при разряде не выключить источник питания, а подать противоположное напряжение? Пример с прямоугольными импульсами, когда напряжение периодически меняется на противоположное.

Python code
-----------

Обработка результатов измерений
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

data_file_r = 'ec_003_С_F100_RC_on_R.csv'
data_file_c = 'ec_003_С_F100_RC_on_C.csv'

# Adjustments F100

r_index_start = 1328
c_index_start = 1778

r_zero_main = 4080
r_zero = -4080
c_zero = -3920
points_shift = 500
num_points = 5000

# Adjustments F167

r_index_start = 1281
c_index_start = 2281

r_zero_main = 4080
r_zero = -4080
c_zero = -3920
points_shift = 500
num_points = 3000

# Adjustments F500

r_index_start = 1589
c_index_start = 1580

r_zero_main = 4120
r_zero = -4000
c_zero = -2020
points_shift = 500
num_points = 2500

ldf_r = pl.scan_csv(downloads.joinpath(f'_NEW\{data_file_r}'), skip_rows=8)\
.rename({'CH2_Voltage(mV)': 'R_Voltage(mV)'})
ldf_c = pl.scan_csv(downloads.joinpath(f'_NEW\{data_file_c}'), skip_rows=8)\
.rename({'CH2_Voltage(mV)': 'C_Voltage(mV)'})

ldf = ldf_r.join(ldf_c, on=['index'], how='inner', suffix='2')

ldf_adj = (
    ldf_r.with_columns(
        (pl.col('index')-r_index_start+points_shift).alias('index'),
        pl.col('CH1_Voltage(mV)')-r_zero_main,
        pl.col('R_Voltage(mV)')-r_zero,
    ).filter((pl.col('index')>0) & (pl.col('index')<num_points))
    .join(
        ldf_c.with_columns(
            (pl.col('index')-c_index_start+points_shift).alias('index'),
            pl.col('CH1_Voltage(mV)')-r_zero_main,
            pl.col('C_Voltage(mV)')-c_zero,
        ).filter((pl.col('index')>0) & (pl.col('index')<num_points)),
        on=['index'], how='inner', suffix='2')
)

print(ldf.head(3).collect())
print(ldf_adj.head(3).collect())

ldf.hvplot.line(
    # xlim=(0, 100), ylim=(0, 100),
    width=400,  # width (default=700)/height (default=300): int
    # rot=90,
    # legend='top_left',
    subplots=True,
    shared_axes=True,
).cols(2)

# save figure and show the plot

ldf_adj.select(pl.exclude(['index', 'CH1_Voltage(mV)2'])).collect().to_pandas()\
.plot().get_figure().savefig(downloads.joinpath(f'_NEW\image.jpeg'))

ldf_adj.select(pl.exclude('CH1_Voltage(mV)2')).hvplot.line(
    # xlim=(0, 100), ylim=(0, 100),
    width=900,  # width (default=700)/height (default=300): int
    height=500,
    # rot=90,
    # legend='top_left',
    # subplots=True,
    # shared_axes=True,
)

Расчет заряда и разряда конденсатора с визуализацией
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

# Charge

import polars as pl
import math
import hvplot.polars  # pip install hvplot
from great_tables import GT

r1 = 1000  # Om
c1 = 0.000001  # 1 uF
u = 2  # V
tau = r1 * c1  # (1 Тау)
num_tau = 5

t_range = np.arange(0, tau * num_tau, tau / 100)

ldf = (
    pl.LazyFrame(
        {
            't': t_range,
            'u': [u * (1 - math.e**(-t/(r1 * c1))) for t in t_range]
        }
    )
    # .filter(pl.col('u')<0.632).filter(pl.col('t')<pl.col('t').min()+tau)
)

display(
    GT(ldf.select(pl.col('u').min().round(3).alias('u_min'), pl.col('u').max().round(3).alias('u_max')).collect())\
    .cols_label(
        u_min=html("U<sub>min</sub>, (V)"),
        u_max=html("U<sub>max</sub>, (V)"),
    )
)

ldf.collect().hvplot.line(
    x='t', y='u',
    ylim=(0, u),
    # width=300,  # width (default=700)/height (default=300): int
)

# Discharge

import polars as pl
import math
import hvplot.polars  # pip install hvplot
from great_tables import GT

r1 = 1000  # Om
c1 = 0.000001  # 1 uF
u = 2  # V
tau = r1 * c1  # (1 Тау)
num_tau = 5

t_range = np.arange(0, tau * num_tau, tau / 100)

ldf = (
    pl.LazyFrame(
        {
            't': t_range,
            'u': [u * math.e**(-t/(r1 * c1)) for t in t_range]
        }
    )
    # .filter(pl.col('u')<0.632).filter(pl.col('t')<pl.col('t').min()+tau)
)

display(
    GT(ldf.select(pl.col('u').max().round(3).alias('u_max'), pl.col('u').min().round(3).alias('u_min')).collect())\
    .cols_label(
        u_max=html("U<sub>max</sub>, (V)"),
        u_min=html("U<sub>min</sub>, (V)"),
    )
)

ldf.collect().hvplot.line(
    x='t', y='u',
    ylim=(0, u),
    # width=300,  # width (default=700)/height (default=300): int
)

Изучение диода
==============

Цель
----

Измерение Вольт-амперной характеристики (ВАХ) диода.

Описание опыта
--------------

Дана RC цепь с генератором пилообразных импульсов.
					  
            │\│ VD1  ┌────┐ R1  
       ┌────┼─│──────┤    ├────┐
       │    │/│      └────┘    │
       │                       │
       │                       │
       │       ┌────────┐      │
       └───────┤  Gen   ├──────┘
               └────────┘

Подать переменное напряжение (треугольник или прямую пилу).
Путем измерения падения напряжения на светодиоде и резисторе определить ток цепи и сопротивление светодиода.

Используя полученные значения тока, построить гравик ВАХ для светодиодов разных цветов.

Ожидаемый результат
-------------------

Теоретически, напряжение открытия светодиодов:

Желтый:  1.5 В.
Красный: 1.5 В.
Зеленый: 2 В.
Синий:   3.5 В.

Лабораторна работа
------------------

Параметры цепи:

Сигнал: прямоугольные импульсы.

R1 = 1 kOm
U =  8 V (-4; +4) (Размах 8 В. необходим только для измерения ВАХ синего светодиода.)
F =  500 Hz.

Изменение падения напряжения на сопротивлении
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

           ┌────┐
       ┌───┤Ch1 ├──────────────┐
       │   └────┘    ┌────┐    │
       │           ┌─┤ Ch2├────┤
       │           │ └────┘    │
       │      VD1  │       R1  │
       │  │\│      │ ┌────┐    │
       ├──┤ ├──────┴─┤    ├────┤
       │  │/│        └────┘    │
       │                       │
       │                       │
       │       ┌────────┐      │
       └───────┤  Gen   ├──────┘
               └────────┘

Схема 1. Измерение на сопротивлении.

Сохранить результаты измерений на любом временном интервале (не обязательно в момент запуска).

Изменение падения напряжения на светодиоде
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

           ┌────┐
       ┌───┤Ch1 ├──────────────┐
       │   └────┘    ┌────┐    │
       │           ┌─┤ Ch2├────┤
       │           │ └────┘    │
       │      R1   │       VD1 │
       │ ┌────┐    │    │\│    │
       ├─┤    ├────┴────┤ ├────┤
       │ └────┘         │/│    │
       │                       │
       │                       │
       │       ┌────────┐      │
       └───────┤  Gen   ├──────┘
               └────────┘

Схема 2. Измерение на диоде.

Сохранить результаты измерений на любом временном интервале (не обязательно в момент запуска).

Ошибки ожидания
---------------

1. 

Выводы
------

1. 

Вопросы
-------

1. Как изменяется сопротивление светодиода? График зависимости от напряжения.
2. Как расчитывать необходимое сопротивление в цепи с светодиодом?

Обработка результатов измерений
-------------------------------

Результаты расчетов по полученным измерениям:

U открытия Yellow = 2.1 В (для красного, прмерно, то же самое)
U открытия Gren   = 2.2 В
U открытия Blue   = 2.8 В

R Yellow = 1300 - 2200 Ом (для красного, прмерно, то же самое)
R Gren   = 1500 - 2600 Ом
R Blue   = 3000 - 4500 Ом

Измерения, сделанные на приобре Жени:

U открытия Yellow = 1.98 В (для красного, прмерно, то же самое)
U открытия Gren   = 2.08 В
U открытия Blue   = 2.72 В

Расчет тока в цепи и сопротивления диода с визуализацией
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. code-block::

	data_file_r = 'ec_004_VD_on_R_Green.csv'
	data_file_x = 'ec_004_VD_on_VD_Green.csv'

	# Adjustments Yellow

	# r_index_start = 2084
	# c_index_start = 1631

	# r_zero_main = 4160
	# r_zero = -3920
	# c_zero = -3880
	# points_shift = 500
	# num_points = 3500

	# Adjustments Blue

	# r_index_start = 2082
	# c_index_start = 2082

	# r_zero_main = 4160
	# r_zero = -3920
	# c_zero = -3880
	# points_shift = 500
	# num_points = 3500

	# Adjustments Green

	r_index_start = 2096
	c_index_start = 2082

	r_zero_main = 4160
	r_zero = -3920
	c_zero = -3920
	points_shift = 500
	num_points = 3500

	ldf_r = pl.scan_csv(downloads.joinpath(f'_NEW\{data_file_r}'), skip_rows=8)\
	.rename({'CH2_Voltage(mV)': 'R_Voltage(mV)'})
	ldf_c = pl.scan_csv(downloads.joinpath(f'_NEW\{data_file_x}'), skip_rows=8)\
	.rename({'CH2_Voltage(mV)': 'VD_Voltage(mV)'})

	ldf = ldf_r.join(ldf_c, on=['index'], how='inner', suffix='2')

	ldf_adj = (
		ldf_r.with_columns(
			(pl.col('index')-r_index_start+points_shift).alias('index'),
			pl.col('CH1_Voltage(mV)')-r_zero_main,
			pl.col('R_Voltage(mV)')-r_zero,
		).filter((pl.col('index')>0) & (pl.col('index')<num_points))
		.join(
			ldf_c.with_columns(
				(pl.col('index')-c_index_start+points_shift).alias('index'),
				pl.col('CH1_Voltage(mV)')-r_zero_main,
				pl.col('VD_Voltage(mV)')-c_zero,
			).filter((pl.col('index')>0) & (pl.col('index')<num_points)),
			on=['index'], how='inner', suffix='2')
	)

	print(ldf.head(3).collect())
	print(ldf_adj.head(10).collect())
	ldf_adj.select(pl.exclude('CH1_Voltage(mV)2')).collect().write_csv(downloads.joinpath('_NEW/result.csv'))

	ldf.hvplot.line(
		# xlim=(0, 100), ylim=(0, 100),
		width=400,  # width (default=700)/height (default=300): int
		# rot=90,
		# legend='top_left',
		subplots=True,
		shared_axes=True,
	).cols(2)

.. code-block::

	ldf_adj.hvplot.line(
		# xlim=(0, 100), ylim=(0, 100),
		width=400,  # width (default=700)/height (default=300): int
		# rot=90,
		# legend='top_left',
		subplots=True,
		shared_axes=True,
	).cols(2)


.. code-block::

	data_file = 'result.csv'

	r1  = 1000  # Om

	ldf = pl.scan_csv(downloads.joinpath(f'_NEW\{data_file}'))

	ldf = ldf.with_columns(
		pl.lit(r1).alias('R(Om)'),
		(pl.col('R_Voltage(mV)') / r1).alias('I(mA)')
	).with_columns(
		(pl.col('VD_Voltage(mV)') / pl.col('I(mA)')).alias('VD_R(Om)')
	)

	ldf.collect().hvplot.line(
		x='index',
		subplots=True,
		shared_axes=False,
	).cols(1)

ВАХ

.. code-block::

	pldf = (
		ldf
		.filter((pl.col('index') > 1500) & (pl.col('index') < 2490))
		.select(pl.col('I(mA)','CH1_Voltage(mV)'))
		# .with_columns(pl.col('CH1_Voltage(mV)') / 1000)
		.collect()
	)

	pldf.to_pandas().plot(x='CH1_Voltage(mV)').get_figure().savefig(downloads.joinpath(f'_NEW\image.jpeg'))

	pldf.hvplot.line(
		x='CH1_Voltage(mV)',
		width=700,  # width (default=700)/height (default=300): int
		height=500,
	)

Сопротивление

.. code-block::

	ldf.filter((pl.col('index') > 2070) & (pl.col('index') < 2490)).select(pl.col('index','VD_R(Om)'))\
	.collect()\
	.hvplot.line(x='index')

Напряжение на диоде и сопротивлении

.. code-block::

	ldf.select(pl.col('index','R_Voltage(mV)','VD_Voltage(mV)')).collect()\
	.to_pandas().plot(x='index').get_figure().savefig(downloads.joinpath(f'_NEW\image.jpeg'))
	# .hvplot.line(x='index')

Список литературы
-----------------

1. http://asciiflow.com/